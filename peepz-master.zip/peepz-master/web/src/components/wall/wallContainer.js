export const mapToProps = state => {
  return {
    user: state.user
  };
};
