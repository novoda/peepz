/*global module*/
module.exports = {};
