/*global module*/
module.exports = 'test-file-stub';
