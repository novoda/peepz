# Peepz [![CircleCI](https://circleci.com/gh/novoda/peepz.svg?style=shield&circle-token=4ea9c7d77dac86224fb061960240bdd9f6e71290)](https://circleci.com/gh/novoda/peepz) [![Coverage Status](https://coveralls.io/repos/github/novoda/peepz/badge.svg?branch=master)](https://coveralls.io/github/novoda/peepz?branch=master)

###Usage

Copy config.json.sample and fill out the fields from your firebase instance.

`npm install && npm start` or yarn

This will install all the required dependencies and start the webpack dev server.
