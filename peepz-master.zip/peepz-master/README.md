# peepz

a lightweight pukka/sqwiggle-like app for web and android.
