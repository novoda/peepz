package com.novoda.peepz;

public interface PictureTakeListener {

    void onPictureTake(byte[] data);

}
