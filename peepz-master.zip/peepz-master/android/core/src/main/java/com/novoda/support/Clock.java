package com.novoda.support;

public interface Clock {

    long currentTimeMillis();

}
