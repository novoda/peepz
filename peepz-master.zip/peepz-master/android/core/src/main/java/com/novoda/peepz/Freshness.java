package com.novoda.peepz;

public enum Freshness {

    SUPER_FRESH,
    NOT_SO_FRESH

}
